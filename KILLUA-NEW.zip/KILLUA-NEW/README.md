# KILLUA NEW

Flutter starter project for building an iOS IPA with Codemagic.

The app opens directly to a Dashboard and does not include the old license screen.
